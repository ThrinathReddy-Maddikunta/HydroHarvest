export default {
  dark: "#1A1A1A",
  grey: "#5E5D5E",
  primary: "#0A4D4A",
};