# AquaReactNative

npx create-expo-app@latest
√ What is your app named? ... aquasave
